/*
 * Copyright (c) 2008-2017 GTONE. All rights reserved.
 *
 * This software is the confidential and proprietary information of GTONE. You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered into with GTONE.
 */
package com.gtone.aml.server.AML_90.AML_90_01.AML_90_01_01;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.JDaoUtil;
import com.gtone.aml.dao.common.JDaoUtilSingle;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.aml.server.util.BizException;
import com.gtone.express.Constants;
import com.gtone.express.server.helper.MessageHelper;
import com.gtone.express.util.FileUtil;

import kr.co.itplus.jwizard.dataformat.DataSet;

/**
*<pre>
* 공지사항 보기
* お知らせ詳細
* Announcement View
*</pre>
*@author syk, hikim
*@version 1.0
*@history 1.0 2010-09-30
*/
public class AML_90_01_01_02 extends GetResultObject {

	private static AML_90_01_01_02 instance = null;

	/**
	 * getInstance
	 * @return AML_90_01_01_02
	 */
	public static AML_90_01_01_02 getInstance() {
		if ( instance == null ) {
			instance = new AML_90_01_01_02();
		}
		return instance;
	}

	/**
	 * <pre>
	 *   공지사항 조회
	 * お知らせの照会
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(공지사항 조회 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(お知らせの照会 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	public DataObj doSearch(DataObj input) {

		DataObj output = new DataObj();
		DataObj output_file = new DataObj();
		JDaoUtil db = null;

		try {

			String query_id = "AML_90_01_01_01_getSearch";
			String sql = JDaoUtilSingle.getSQL(query_id);
			sql += " and NOTI_ID = ? ";

			Object[] obj = { input.getText("NOTI_ID") };
			output = JDaoUtilSingle.getData(query_id, sql, obj);

			// Stoed XSS
			// TITLE, CONTENT
			if ( output != null && output.size() > 0 ) {
				String sTitle = (String) output.get("TITLE");
				sTitle = sTitle.replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("\'", "&#039;");
				output.set("TITLE", sTitle);

				String sContent = (String) output.get("CONTENT");
				sContent = sContent.replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("\'", "&#039;");
				output.set("CONTENT", sContent);
			}

			// Attachments ==========================================================
			String BOARD_ID = input.getText("BOARD_ID");
			String BOARD_SEQ = input.getText("NOTI_ID");

			Object[] obj1 = { BOARD_ID, BOARD_SEQ };

			output_file = JDaoUtilSingle.getData("AML_90_01_03_02_doDetail_NIC90B_2_ATTACH_FILE", obj1);
			if ( output_file.getCount("FILE_SEQ") > 0 ) {

				for ( int i = 0; i < output_file.getCount("FILE_SEQ"); i++ ) {
					output.put("FILE_SEQ", output_file.getText("FILE_SEQ", i), i);
					output.put("FILE_POS", output_file.getText("FILE_POS", i), i);
					output.put("USER_FILE_NM", output_file.getText("USER_FILE_NM", i), i);
					output.put("PHSC_FILE_NM", output_file.getText("PHSC_FILE_NM", i), i);
					output.put("FILE_SIZE", output_file.getText("FILE_SIZE", i), i);
					output.put("DOWNLOAD_COUNT", output_file.getText("DOWNLOAD_COUNT", i), i);
				}
			}
			// ===============================================================================
			String NOTI_ID = input.getText("NOTI_ID");
			db = new JDaoUtil();
			db.begin();
			if ( db.setData("AML_90_01_01_02_upViewCount_C_NOTI", new Object[] {NOTI_ID}) != 1 ) {
				throw new BizException("View Count : update error..");
			}
			db.commit();
			output.put("ERRCODE", "00000");
			output.put("ERRMSG", "");

		} catch (Exception e) {

			Log.logAML(Log.ERROR, this.getClass(), "getNOTI_ID_info", e.getMessage());
			output = new DataObj();

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
		}
		return output;
	}
	public DataObj doSearch2(DataObj input) {

		DataObj output_file = null;
		DataSet gdRes = null;
		
		try {		
		output_file = MDaoUtilSingle.getData("AML_90_01_01_03_getAttachSearch",(HashMap) input);
		
        if (output_file.getCount("FILE_SEQ") > 0) {
          gdRes = Common.setGridData(output_file);
        } else {
        	output_file.put("ERRMSG",MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"), "조회된 정보가 없습니다."));
        }
        output_file.put("ERRCODE", "00000");
        output_file.put("gdRes", gdRes);
        
	} catch (AMLException e) {

		Log.logAML(Log.ERROR, this.getClass(), "doSearch2(Exception)", e.getMessage());
		output_file = new DataObj();

		output_file.put("ERRCODE", "00001");
		output_file.put("ERRMSG", e.toString());
	} catch (Exception e) {

		Log.logAML(Log.ERROR, this.getClass(), "doSearch2(Exception)", e.getMessage());
		output_file = new DataObj();

		output_file.put("ERRCODE", "00001");
		output_file.put("ERRMSG", e.toString());
	}
	return output_file;
}

	/**
	 * <pre>
	 *   공지사항 삭제
	 * お知らせの削除
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(공지사항 삭제 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(お知らせの削除 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	public DataObj goDelete(DataObj input ) {
		
		System.out.println("=============================goDelete=============================");
		
		DataObj output = new DataObj();
		//DataSet ds = new DataSet();
		String NOTI_ID = input.getText("NOTI_ID");
		String BOARD_ID = input.getText("BOARD_ID");


		output.add("BOARD_SEQ", NOTI_ID);
		output.add("BOARD_ID", BOARD_ID);
		

		@SuppressWarnings("unused")
		int result = 0;

		try {
			
			HashMap hm = new HashMap();
			hm.put("BOARD_ID", BOARD_ID);
			hm.put("BOARD_SEQ", NOTI_ID);			
			
			DataObj fdo = MDaoUtilSingle.getData("AML_90_01_01_03_getAttachSearch", hm);			
			List<HashMap> fileList = fdo.getRowsToMap();
			System.out.println("fileList ::::::::"+fileList.toString());	
			StringBuffer strPath = new StringBuffer(256);
			
			for(int i=0; i < fileList.size(); i++)
			{
				strPath.setLength(0);
				strPath.append(Constants._UPLOAD_NOTICE_DIR);
				strPath.append(fileList.get(i).get("FILE_POS"));
				strPath.append('/');
				strPath.append(fileList.get(i).get("PHSC_FILE_NM"));
				String filePath = strPath.toString();
				//String filePath = Constants._UPLOAD_NOTICE_DIR+fileList.get(i).get("FILE_POS")+"/"+fileList.get(i).get("PHSC_FILE_NM");
				FileUtil.deleteFile(filePath);
			}	


			Object[] obj1 = { NOTI_ID };
			result = JDaoUtilSingle.setData("AML_90_01_01_02_doDelete_C_NOTI", obj1);

			input.add("BOARD_SEQ", NOTI_ID);
			result = MDaoUtilSingle.setData("AML_90_01_01_02_doDelete_NIC90B_2", output);
	
			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 화면 popUp 메세지 출력시 정의함.

		} catch (AMLException e) {
			
			e.printStackTrace();

			Log.logAML(Log.ERROR, this, "goDelete", e.getMessage());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어
		} catch (IOException e) {
			
			e.printStackTrace();

			Log.logAML(Log.ERROR, this, "goDelete", e.getMessage());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어
		} catch (Exception e) {
			
			e.printStackTrace();

			Log.logAML(Log.ERROR, this, "goDelete", e.getMessage());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어
		}
		return output;
	}

}
