/*
 * Copyright (c) 2008-2017 GTONE. All rights reserved.
 *
 * This software is the confidential and proprietary information of GTONE. You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered into with GTONE.
 */
package com.gtone.aml.server.AML_90.AML_90_01.AML_90_01_02;

import java.util.HashMap;

import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.JDaoUtilSingle;
import com.gtone.express.server.helper.MessageHelper;

/**
*<pre>
* Q&A 답변
* Q&A回答
* Q&A Answer
*</pre>
*@author syk, hikim
*@version 1.0
*@history 1.0 2010-09-30
*/
public class AML_90_01_02_05 extends GetResultObject {

	private static AML_90_01_02_05 instance = null;

	/**
	 * getInstance
	 * @return AML_90_01_02_05
	 */
	public static AML_90_01_02_05 getInstance() {
		if ( instance == null ) {
			instance = new AML_90_01_02_05();
		}
		return instance;
	}

	/**
	 * <pre>
	 *   Q&A 답변 저장
	 * Q&A回答の保存
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA( Q&A 답변 저장 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(Q&A回答の保存 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public DataObj doAnswer(DataObj input) {

		DataObj output = new DataObj();
		@SuppressWarnings("unused")
		int result = 0;
		try {

			String STATE = input.getText("STATE");

			if ( "8103".equals(STATE) ) {
				input.add("END_DT", jspeed.base.util.DateHelper.currentTime("yyyyMMdd"));
			} else {
				input.add("END_DT", "");
			}

			result = JDaoUtilSingle.setData("AML_90_01_02_05_doAnswer_C_QA", (HashMap) input);

			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 출력 화면 상태 표시에 출력됨
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 화면 popUp 메세지 출력시 정의함.

			return output;

		} catch (Exception e) {

			Log.logAML(Log.ERROR, this, "doModify", e.toString());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어

			return output;
		}
	}

}
