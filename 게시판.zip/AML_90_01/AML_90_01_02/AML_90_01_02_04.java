/*
 * Copyright (c) 2008-2017 GTONE. All rights reserved.
 *
 * This software is the confidential and proprietary information of GTONE. You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered into with GTONE.
 */
package com.gtone.aml.server.AML_90.AML_90_01.AML_90_01_02;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.basic.common.util.Util;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.JDaoUtil;
import com.gtone.aml.dao.common.JDaoUtilSingle;
import com.gtone.aml.server.common.CommonAuth;
import com.gtone.aml.user.SessionAML;
import com.gtone.express.server.helper.MessageHelper;
import com.itplus.common.server.user.SessionHelper;

import jspeed.base.http.AttachFileDataSource;
import jspeed.base.http.MultipartRequest;
import jspeed.base.jdbc.BaseSQLException;
import jspeed.base.jdbc.JDBCServiceException;
import jspeed.base.jdbc.QueryHelper;
import jspeed.base.property.PropertyService;

/**
*<pre>
* Q&A 수정
* Q&A修正
* Q&A Modify
*</pre>
*@author syk, hikim
*@version 1.0
*@history 1.0 2010-09-30
*/
public class AML_90_01_02_04 extends GetResultObject {

    private static AML_90_01_02_04 instance = null;
        
    /**
     * getInstance
     * @return AML_90_01_02_04
     */
    public static AML_90_01_02_04 getInstance() {
        if(instance == null) {
            instance = new AML_90_01_02_04();
        }
        return instance;
    }
    
    /**
     * <pre>
     *   Q&A 수정
     * Q&A修正
     * @en
     * </pre>
     *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     *@return GRID_DATA(Q&A 수정 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *GRID_DATA(Q&A修正 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     *@throws Exception
     */    
    @SuppressWarnings("rawtypes")
    public DataObj doModify(MultipartRequest req){
    	
    	String filePath = PropertyService.getInstance().getProperty("aml.config","uploadPath.notice");
    	
    	String fileFullPath = "";
    	JDaoUtil daoUtil = null;
    	ResultSet rs = null;
    	
        SessionHelper helper = new SessionHelper(req.getSession());
          
        DataObj     output    = new DataObj();
        
        String KIND       = Util.nvl(req.getParameter("KIND"));
        String TITLE      = Util.nvl(req.getParameter("TITLE"));
        String CONTENT    = Util.nvl(req.getParameter("CONTENT"));
		
		TITLE   =  TITLE.replaceAll("<","&lt;");
        TITLE   =  TITLE.replaceAll(">","&gt;");
        CONTENT   =  CONTENT.replaceAll("<","&lt;");
        CONTENT   =  CONTENT.replaceAll(">","&gt;");
        

        
        String SEQ        = Util.nvl(req.getParameter("SEQ"));
        String BOARD_ID   = Util.nvl(req.getParameter("BOARD_ID"));       
        String BOARD_SEQ  = Util.nvl(req.getParameter("SEQ"));
        String UPD_ID     = Util.nvl(helper.getUserId());

        @SuppressWarnings("unused")
        int         result     = 0;
        try {
        	
        	
        	DataObj outputAuth = CommonAuth.checkWinAuth( new SessionAML(req.getSession()),req.getParameter("pageID"));
			if("".equals(outputAuth.getText("U")) || "N".equals(outputAuth.getText("U")) ) {
				output = new DataObj();
				output.put("ERRCODE", "00001");
				output.put("ERRMSG", "권한이 없습니다.");
				return output;
			}
			
        	daoUtil = new JDaoUtil();
        	daoUtil.begin();
        	
        	Object[] obj1 = {
        			 KIND
        			,TITLE
        			,CONTENT
        			,SEQ
               };

            result = JDaoUtilSingle.setData("AML_90_01_02_04_doModify_C_QA", obj1);                
                
            // delete
            Object[] obj2 = {BOARD_ID, BOARD_SEQ};
            result= daoUtil.setData( "AML_90_01_03_02_doDelete_NIC90B_2", obj2);
        
            // file path
            fileFullPath = filePath+"/"+BOARD_ID+"/"+BOARD_SEQ+"/";
            fileFullPath = fileFullPath.replace("/", System.getProperty("file.separator"));
            
            String[]  NOTI_ATTACH 				= req.getParameterValues("NOTI_ATTACH");
            String[]  FILE_SEQ             		= req.getParameterValues("FILE_SEQ");
            String[]  FILE_POS_temp         	= new String[10];
            String[]  USER_FILE_NM_temp  		= new String[10];
            String[]  PHSC_FILE_NM_temp  		= new String[10];
            String[]  FILE_SIZE_temp        	= new String[10];
            String[]  DOWNLOAD_COUNT_temp		= new String[10];    
            
            AttachFileDataSource[]     attachFileDSs = req.getAttachFiles("NOTI_ATTACH");
            
            
            for(int i =0; i<FILE_SEQ.length; i++){

                QueryHelper query = new QueryHelper();
                rs = query.executeQuery(" SELECT 		FILE_POS "
                		                    + "         ,USER_FILE_NM "
                		                    + "         ,PHSC_FILE_NM "
                		                    + "         ,FILE_SIZE "
                		                    + "         ,DOWNLOAD_COUNT "
                		                    + " FROM NIC90B_2 "
                		                    + " WHERE BOARD_ID	 = '" + BOARD_ID + "' " 
                		                    + " AND BOARD_SEQ  	=  "+ BOARD_SEQ 
                		                    + " AND FILE_SEQ      = '" + FILE_SEQ[i]   + "' "  );
                
                if (rs.next()) {
                    FILE_POS_temp[i]		= rs.getString(1);
                    USER_FILE_NM_temp[i]	= rs.getString(2);
                    PHSC_FILE_NM_temp[i]	= rs.getString(3);
                    FILE_SIZE_temp[i]		= rs.getString(4);
                    DOWNLOAD_COUNT_temp[i]	= rs.getString(5);
                }
                
            }
            
            
            int count_file = 0;
            
            // ==================================================================    
            
            count_file = 0;
            int FILE_SEQ_max = 0;
            long fileLen=0;
            
            output = JDaoUtilSingle.getData( "AML_90_01_03_04_MAX_NIC90B_2",new Object[]{BOARD_ID,BOARD_SEQ} );
            FILE_SEQ_max = output.getInt("FILE_SEQ"); 
            
            for(int i =0; i<FILE_SEQ.length; i++){
                
                if(!FILE_SEQ[i].equals("0") && NOTI_ATTACH[i].equals("")){
                	
                	System.out.println("첨부파일번호가 있고 첨부파일이 없을때");
                	// 첨부정보 저장처리
                    obj1 = new Object [] {
                            BOARD_ID
                           ,BOARD_SEQ
                           ,FILE_SEQ[i]
                           ,FILE_POS_temp[i]
                           ,USER_FILE_NM_temp[i]
                           ,PHSC_FILE_NM_temp[i]
                           ,FILE_SIZE_temp[i]                       
                           ,DOWNLOAD_COUNT_temp[i]
                           ,UPD_ID
                    };
                                            
                    result = daoUtil.setData( "AML_90_01_03_03_doSave_NIC90B_2",obj1 );                    
                    
                }else if((!FILE_SEQ[i].equals("0") &&  !NOTI_ATTACH[i].equals(""))
                		|| (FILE_SEQ[i].equals("0") &&  !NOTI_ATTACH[i].equals(""))){
                    
                	System.out.println("첨부파일번호가 있고 첨부파일이 있을때(기존파일을 변경)");
					System.out.println("첨부파일번호가 없고 첨부파일이 있을때(신규파일 추가)");
                    FILE_SEQ_max++;
                    
                    String PHSC_FILE_NM = BOARD_SEQ + "_" + (FILE_SEQ_max);
                    req.upload(attachFileDSs[count_file], fileFullPath, PHSC_FILE_NM );
                    fileLen = attachFileDSs[count_file].getSize();                
                    if ( fileLen > 1 ) {
                    	fileLen = fileLen - 2;  //getSize시 원래사이즈보다 2가 큼
                    }
                    
                    obj1 = new Object [] {
                            BOARD_ID
                           ,BOARD_SEQ
                           ,FILE_SEQ_max
                           ,fileFullPath
                           ,attachFileDSs[count_file].getName()
                           ,PHSC_FILE_NM
                           ,fileLen                       
                           ,0
                           ,UPD_ID
                    };                    
                    
                    
                    result = daoUtil.setData( "AML_90_01_03_03_doSave_NIC90B_2",obj1 );
                    count_file ++;
                    
                }
                
            }
            
            daoUtil.commit();

            output.put("ERRCODE","00000");
            output.put("ERRMSG"    ,MessageHelper.getInstance().getMessage("0002",helper.getLangType(),"정상 처리되었습니다."));//PHH 2009.03.02 다국어
            output.put("WINMSG"    ,MessageHelper.getInstance().getMessage("0002",helper.getLangType(),"정상 처리되었습니다."));//PHH 2009.03.02 다국어 // 화면 popUp 메세지 출력시 정의함.
            
        }catch(JDBCServiceException e){
            try{ 
            	if(daoUtil != null) {
            		daoUtil.rollback(); 
            	}
            } catch(Exception ee) {
            	Log.logAML(Log.ERROR, this, "doModify",ee.toString());
            }
            Log.logAML(Log.ERROR, this, "doModify", e.toString());
            
            output    = new DataObj();
            output.put("ERRCODE"    ,"00001");
            output.put("ERRMSG"        ,e.toString());
            //output.put("WINMSG"        ,MessageHelper.getInstance().getMessage("0005",helper.getLangType(),"처리중 오류가 발생하였습니다."));//PHH 2009.03.02 다국어
            
        }catch(BaseSQLException e){
            try{ 
            	if(daoUtil != null) {
            		daoUtil.rollback(); 
            	}
            } catch(Exception ee) {
            	Log.logAML(Log.ERROR, this, "doModify",ee.toString());
            }
            Log.logAML(Log.ERROR, this, "doModify", e.toString());
            
            output    = new DataObj();
            output.put("ERRCODE"    ,"00001");
            output.put("ERRMSG"        ,e.toString());
            //output.put("WINMSG"        ,MessageHelper.getInstance().getMessage("0005",helper.getLangType(),"처리중 오류가 발생하였습니다."));//PHH 2009.03.02 다국어
            
        }catch(NumberFormatException e){
            try{ 
            	if(daoUtil != null) {
            		daoUtil.rollback(); 
            	}
            } catch(Exception ee) {
            	Log.logAML(Log.ERROR, this, "doModify",ee.toString());
            }
            Log.logAML(Log.ERROR, this, "doModify", e.toString());
            
            output    = new DataObj();
            output.put("ERRCODE"    ,"00001");
            output.put("ERRMSG"        ,e.toString());
            //output.put("WINMSG"        ,MessageHelper.getInstance().getMessage("0005",helper.getLangType(),"처리중 오류가 발생하였습니다."));//PHH 2009.03.02 다국어
            
        }catch(SQLException e){
            try{ 
            	if(daoUtil != null) {
            		daoUtil.rollback(); 
            	}
            } catch(Exception ee) {
            	Log.logAML(Log.ERROR, this, "doModify",ee.toString());
            }
            Log.logAML(Log.ERROR, this, "doModify", e.toString());
            
            output    = new DataObj();
            output.put("ERRCODE"    ,"00001");
            output.put("ERRMSG"        ,e.toString());
            //output.put("WINMSG"        ,MessageHelper.getInstance().getMessage("0005",helper.getLangType(),"처리중 오류가 발생하였습니다."));//PHH 2009.03.02 다국어
            
        }catch(IOException e){
            try{ 
            	if(daoUtil != null) {
            		daoUtil.rollback(); 
            	}
            } catch(Exception ee) {
            	Log.logAML(Log.ERROR, this, "doModify",ee.toString());
            }
            Log.logAML(Log.ERROR, this, "doModify", e.toString());
            
            output    = new DataObj();
            output.put("ERRCODE"    ,"00001");
            output.put("ERRMSG"        ,e.toString());
            //output.put("WINMSG"        ,MessageHelper.getInstance().getMessage("0005",helper.getLangType(),"처리중 오류가 발생하였습니다."));//PHH 2009.03.02 다국어
            
        }catch(Exception e){
            try{ 
            	if(daoUtil != null) {
            		daoUtil.rollback(); 
            	}
            } catch(Exception ee) {
            	Log.logAML(Log.ERROR, this, "doModify",ee.toString());
            }
            Log.logAML(Log.ERROR, this, "doModify", e.toString());
            
            output    = new DataObj();
            output.put("ERRCODE"    ,"00001");
            output.put("ERRMSG"        ,e.toString());
            //output.put("WINMSG"        ,MessageHelper.getInstance().getMessage("0005",helper.getLangType(),"처리중 오류가 발생하였습니다."));//PHH 2009.03.02 다국어
            
        } finally {
        	if(daoUtil!=null) {
        		daoUtil.close();
        	}
        }
        return output;
    }    
    
}
