/*
 * Copyright (c) 2008-2017 GTONE. All rights reserved.
 *
 * This software is the confidential and proprietary information of GTONE. You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered into with GTONE.
 */
package com.gtone.aml.server.AML_90.AML_90_01.AML_90_01_02;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.basic.common.util.Util;
import com.gtone.aml.common.action.AMLCommonLogAction;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.JDaoUtil;
import com.gtone.aml.dao.common.MDaoUtil;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.express.Constants;
import com.gtone.express.domain.FileVO;
import com.gtone.express.server.helper.MessageHelper;
import com.gtone.express.util.FileUtil;
import com.itplus.common.server.user.SessionHelper;

import jbit.common.util.ParamUtil;
import jspeed.base.http.AttachFileDataSource;
import jspeed.base.http.MultipartRequest;
import jspeed.base.property.PropertyService;

/**
*<pre>
* Q/A 등록
* Q&A登録
* Q/A Register
*</pre>
*@author syk, hikim
*@version 1.0
*@history 1.0 2010-09-30
*/
@Controller
public class AML_90_01_02_02 extends GetResultObject {

	private static AML_90_01_02_02 instance = null;

	/**
	 * getInstance
	 * @return AML_90_01_02_02
	 */
	public static AML_90_01_02_02 getInstance() {
		if ( instance == null ) {
			instance = new AML_90_01_02_02();
		}
		return instance;
	}

	/**
	 * <pre>
	 *   Q&A 저장
	 * Q&A保存
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(Q&A 저장 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(Q&A保存 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception 
	 */
	public DataObj doSave(MultipartRequest req) {
		String filePath = PropertyService.getInstance().getProperty("aml.config", "uploadPath.notice");

		String fileFullPath = "";
		JDaoUtil daoUtil = null;

		DataObj output = new DataObj();
		SessionHelper helper = new SessionHelper(req.getSession());

		@SuppressWarnings("unused")
		int result = 0;

		try {
			daoUtil = new JDaoUtil();

			daoUtil.begin();
			String BOARD_ID = Util.nvl(req.getParameter("BOARD_ID"));
			String KIND = Util.nvl(req.getParameter("KIND"));
			String TITLE = Util.nvl(req.getParameter("TITLE"));
			String CONTENT = Util.nvl(req.getParameter("CONTENT"));

			String REG_ID = Util.nvl(req.getParameter("REG_ID"));
			String REG_NAME = Util.nvl(req.getParameter("REG_NAME"));
			String STATE = Util.nvl(req.getParameter("STATE"));
			String REG_DT = jspeed.base.util.DateHelper.currentTime("yyyyMMdd");
			String PKG_NAME = Util.nvl(PropertyService.getInstance().getProperty("aml.config", "PKG_NAME"), "AML");
			String SEQ = Util.nvl(req.getParameter("SEQ"));

			output.add("BOARD_ID", BOARD_ID);
			output.add("KIND", KIND);
			output.add("TITLE", TITLE);
			output.add("CONTENT", CONTENT);
			output.add("REG_ID", REG_ID);
			output.add("REG_NAME", REG_NAME);
			output.add("STATE", STATE);
			output.add("REG_DT", REG_DT);
			output.add("PKG_NAME", PKG_NAME);
			output.add("SEQ", SEQ);

			result = MDaoUtilSingle.setData("AML_90_01_02_02_doSave_C_QA", output);

			/*
			 * Attachments Positioning
			 */
			fileFullPath = filePath + "/" + BOARD_ID + "/" + SEQ + "/";

			fileFullPath = fileFullPath.replace("/", System.getProperty("file.separator"));

			/*
			 * Attachments Save/ DB Attachment content DB Save
			 */
			if ( req.getAttach("NOTI_ATTACH") != null ) {

				AttachFileDataSource[] attachFileDSs = req.getAttachFiles("NOTI_ATTACH");
				String PHSC_FILE_NM = "";
				long fileLen = 0;
				
				for ( int i = 0; i < attachFileDSs.length; i++ ) {

					PHSC_FILE_NM = SEQ + "_" + (i + 1);
					req.upload(attachFileDSs[i], fileFullPath, PHSC_FILE_NM);
					fileLen = attachFileDSs[i].getSize();
					
					if ( fileLen > 1 ) {
						fileLen = fileLen - 2;
					}
					
					Object[] obj1 = new Object[] { BOARD_ID
							                     , SEQ
							                     , "" + (i + 1)
							                     , fileFullPath
							                     , attachFileDSs[i].getName()
							                     , PHSC_FILE_NM
							                     , fileLen
							                     , 0
							                     , REG_ID 
							                     };

					result = daoUtil.setData("AML_90_01_03_03_doSave_NIC90B_2", obj1);
				}
			}
			daoUtil.commit();

			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", helper.getLangType(), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 출력 화면 상태 표시에 출력됨
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", helper.getLangType(), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 화면 popUp 메세지 출력시 정의함.

			return output;

		} catch (IOException e) {
			try {
				if ( daoUtil != null ) {
					daoUtil.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "getSearch", ee.toString());
			}
			Log.logAML(Log.ERROR, this, "getSearch", e.toString());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", helper.getLangType(), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어

		} catch (AMLException e) {
			try {
				if ( daoUtil != null ) {
					daoUtil.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "getSearch", ee.toString());
			}
			Log.logAML(Log.ERROR, this, "getSearch", e.toString());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", helper.getLangType(), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어

		} catch (Exception e) {
			try {
				if ( daoUtil != null ) {
					daoUtil.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "getSearch", ee.toString());
			}
			Log.logAML(Log.ERROR, this, "getSearch", e.toString());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", helper.getLangType(), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어

		} finally {
			try {
				if ( daoUtil != null ) {
					daoUtil.close();
				}
			} catch (Exception e) {
				Log.logAML(Log.ERROR, this, "getSearch", e.toString());
			}
		}
		return output;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping("/bbs/doQaSave.do")
	public String doSave(HttpServletRequest request, ModelMap model ,FileVO paramVO, @RequestParam Map inHash ) 
	{
		SessionHelper helper = new SessionHelper(request.getSession());
		String BOARD_ID = Util.nvl(request.getParameter("BOARD_ID"));
		String REG_ID = Util.nvl(helper.getUserId());
		String SEQ = Util.nvl(request.getParameter("SEQ"));
		String PKG_NAME = Util.nvl(PropertyService.getInstance().getProperty("aml.config", "PKG_NAME"), "AML");
		String REG_DT = jspeed.base.util.DateHelper.currentTime("yyyyMMdd");
		String CONTENT = Util.nvl(request.getParameter("CONTENT"));
		
		MDaoUtil mDao = null;			

		@SuppressWarnings("unused")
		int result = 0;

		try {
			mDao = new MDaoUtil();
			HashMap hm = ParamUtil.getReqParamHashMap(request);
			hm.put("PKG_NAME", PKG_NAME);
			hm.put("REG_DT", REG_DT);
			hm.put("CONTENT", CONTENT);
			System.out.println("hm ::::::::"+hm.toString());
			
			MDaoUtilSingle.setData("AML_90_01_02_02_doSave_C_QA", hm);

			// 파일 이동 및 처리
			if(null != paramVO.getFilePaths()) 
			{
				for(int i = 0; i < paramVO.getFilePaths().length; i++)
				{
					if(paramVO.getFilePaths()[i].indexOf(Constants.COMMON_TEMP_FILE_UPLOAD_DIR) > -1)
					{
						File	tempDir		= new File(paramVO.getFilePaths()[i]);				
						File	tempFile	= new File(tempDir, paramVO.getStoredFileNms()[i]);
						
						if(tempFile.isFile())
						{								
							File	realFile	= FileUtil.renameTo(tempFile, Constants._UPLOAD_QA_DIR);
							
							String[]	filePath	= paramVO.getFilePaths();
							filePath[i]				= StringUtils.replace(realFile.getParent(),Constants._UPLOAD_QA_DIR,"");
							
							paramVO.setFilePath(filePath[i]);
							paramVO.setFilePath(paramVO.getFilePath().replaceAll("\\\\", "/"));
						}
						else
						{
							String[]	filePath	= paramVO.getFilePaths();
							filePath[i]				= StringUtils.replace(filePath[i], Constants.COMMON_TEMP_FILE_UPLOAD_DIR, Constants._UPLOAD_QA_DIR);
							
							paramVO.setFilePath(filePath[0]);
							paramVO.setFilePath(paramVO.getFilePath().replaceAll("\\\\", "/"));
						}
					}else {
						String[]	filePath	= paramVO.getFilePaths();
						filePath[i]				= StringUtils.replace(filePath[i], Constants.COMMON_TEMP_FILE_UPLOAD_DIR, Constants._UPLOAD_QA_DIR);
						
						paramVO.setFilePath(filePath[i]);
						paramVO.setFilePath(paramVO.getFilePath().replaceAll("\\\\", "/"));
					}
				}
		
				 System.out.println("FILEPATH============="+paramVO.getFilePath());
				//파일일괄 인서트
				for(int i = 0; i < paramVO.getFilePaths().length; i++)
				{
					DataObj obj11 = new DataObj();
					obj11.put("BOARD_ID", BOARD_ID);
		            obj11.put("BOARD_SEQ", SEQ);
		            obj11.put("FILE_SEQ", ""+(i+1));
		            obj11.put("FILE_POS", paramVO.getFilePath());
		            obj11.put("USER_FILE_NM", paramVO.getOrigFileNms()[i]);
		            obj11.put("PHSC_FILE_NM", paramVO.getStoredFileNms()[i]);
		            obj11.put("FILE_SIZE", paramVO.getFileSizes()[i]);
		            obj11.put("DOWNLOAD_COUNT", 0);
		            obj11.put("REG_ID", REG_ID);
		          
		            result = mDao.setData("AML_90_01_01_03_doSave_NIC90B_2", obj11);
					
				}
			}
			
			mDao.commit();
			
			model.addAttribute("status", "success");
		    model.addAttribute("serviceMessage", "저장 처리되었습니다.");
		    
		    /* AML Page Log 등록 처리 모듈  **********************************************/
        	AMLCommonLogAction amlCommonLogAction =  new AMLCommonLogAction();
        	amlCommonLogAction.amlLogInsert(request, inHash);
            /* ***************************************************************************/
        	
		}catch(AMLException e)
		{
			e.printStackTrace();
			try {
				if (mDao != null) {
					mDao.rollback();
				}
			} catch (AMLException e1) {
				Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
				model.addAttribute("status", "fail");
			    model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
			}
			Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
			model.addAttribute("status", "fail");
		    model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			try {
				if (mDao != null) {
					mDao.rollback();
				}
			} catch (AMLException e1) {
				Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
				model.addAttribute("status", "fail");
			    model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
			}
			Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
			model.addAttribute("status", "fail");
		    model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
		}finally {
			mDao.close();
		}
		
		return "jsonView";
  }

	
	  @SuppressWarnings({ "rawtypes", "unchecked" })
	  @RequestMapping("/bbs/doQaUpdate.do")
	  public String doUpdate(HttpServletRequest request, ModelMap model ,FileVO paramVO, @RequestParam Map inHash ) 
	  {
		  	SessionHelper helper = new SessionHelper(request.getSession());
			String BOARD_ID = Util.nvl(request.getParameter("BOARD_ID"));
			String REG_ID = Util.nvl(helper.getUserId());
			String SEQ = Util.nvl(request.getParameter("SEQ"));
			//String PKG_NAME = Util.nvl(PropertyService.getInstance().getProperty("aml.config", "PKG_NAME"), "AML");
			//String REG_DT = jspeed.base.util.DateHelper.currentTime("yyyyMMdd");

			MDaoUtil mDao = null;			
			try
			{	
				mDao = new MDaoUtil();
				HashMap hm = ParamUtil.getReqParamHashMap(request);
				System.out.println("hm ::::::::"+hm.toString());
				
				mDao.setData("AML_90_01_02_02_doUpdate_C_QA", hm);
				

		        @SuppressWarnings("unused")
		        int result = 0;
		       
		        //기존 파일목록  수정추가1
				DataObj fdo = MDaoUtilSingle.getData("AML_90_01_01_03_getAttachSearch",hm);
				List<HashMap> fileList = fdo.getRowsToMap();
				System.out.println("fileList ::::::::"+fileList.toString());				
				//추가1
				
		        // 파일 이동 및 처리
				if((null == paramVO.getFilePaths()) == false) 
				{
					for(int i = 0; i < paramVO.getFilePaths().length; i++)
					{
						if(paramVO.getFilePaths()[i].indexOf(Constants.COMMON_TEMP_FILE_UPLOAD_DIR) > -1)
						{
							File	tempDir		= new File(paramVO.getFilePaths()[i]);				
							File	tempFile	= new File(tempDir, paramVO.getStoredFileNms()[i]);
							
							if(tempFile.isFile())
							{								
								File	realFile	= FileUtil.renameTo(tempFile, Constants._UPLOAD_QA_DIR);
								
								String[]	filePath	= paramVO.getFilePaths();
								filePath[i]				= StringUtils.replace(realFile.getParent(),Constants._UPLOAD_QA_DIR,"");
								
								paramVO.setFilePath(filePath[i]);
								paramVO.setFilePath(paramVO.getFilePath().replaceAll("\\\\", "/"));
							}
							else
							{
								String[]	filePath	= paramVO.getFilePaths();
								filePath[i]				= StringUtils.replace(filePath[i], Constants.COMMON_TEMP_FILE_UPLOAD_DIR, Constants._UPLOAD_QA_DIR);
								
								paramVO.setFilePath(filePath[0]);
							}
						}else {							
							String[]	filePath	= paramVO.getFilePaths();
							filePath[i]				= StringUtils.replace(filePath[i], Constants.COMMON_TEMP_FILE_UPLOAD_DIR, Constants._UPLOAD_QA_DIR);
							
							paramVO.setFilePath(filePath[0]);
							paramVO.setFilePath(paramVO.getFilePath().replaceAll("\\\\", "/"));
						}
					}
					
					System.out.println("fileList ::::::::"+fileList.toString());
					//기존파일 목록 비교 후 삭제처리	수정추가 2					
					for(int i=0; i < fileList.size(); i++)
					{
						boolean btn = false;
						 
						for(int k = 0; k < paramVO.getFilePaths().length; k++)
						{					
							String r = paramVO.getStoredFileNms()[k];			
							
							if((r.equals(fileList.get(i).get("PHSC_FILE_NM"))) == false)
							{
								btn = true;
							}
							else
							{
								btn = false;						
								break;
							}
						}
						
						//넘어온 값과 기존파일목록에 존재하지 않으면 삭제
						if(btn)
						{
						/*
						 * String filePath =
						 * fileList.get(i).get("FILE_POS")+File.separator+fileList.get(i).get(
						 * "PHSC_FILE_NM"); FileUtil.deleteFile(filePath);
						 */
							String filePath = Constants._UPLOAD_QA_DIR+fileList.get(i).get("FILE_POS")+"/"+fileList.get(i).get("PHSC_FILE_NM");
							FileUtil.deleteFile(filePath);
						}
					}
					
					//db 파일 삭제
					mDao.setData("AML_90_01_01_03_doDelete_NIC90B_2", hm);					
					
				/*
				 * String RPT_GJDT = Util.replace(Util.nvl(hm.get("RPT_GJDT")), "-", ""); String
				 * FIU_RPT_GJDT = Util.replace(Util.nvl(hm.get("FIU_RPT_GJDT")), "-", "");
				 * String DR_OP_JKW_NO = Util.nvl(helper.getLoginId()); String ATTCH_FILE_NO =
				 * Util.nvl(hm.get("ATTCH_FILE_NO")); String BAS_YYMM =
				 * Util.replace(Util.nvl(hm.get("BAS_YYMM")), "-", "");
				 * 
				 * if("".equals(ATTCH_FILE_NO)) { // output =
				 * mDao.getData("comm.RBA_10_02_01_01_getRbaAttchFileSeq", hm); output =
				 * mDao.getData("AML_90_01_01_03_NIC90B_2_SEQ_nextval", hm); ATTCH_FILE_NO =
				 * output.getText("SEQ"); }
				 * 
				 * Log.logAML(Log.DEBUG, this, "#### ATTCH_FILE_NO!!! [" + ATTCH_FILE_NO+ "]");
				 * /// 추가2
				 */					 
					//파일일괄 인서트
					
					System.out.println("hm ::::::::"+hm.toString());
					for(int i = 0; i < paramVO.getFilePaths().length; i++)
					{
						DataObj obj11 = new DataObj();
						obj11.put("BOARD_ID", BOARD_ID);
			            obj11.put("BOARD_SEQ", SEQ);
			            obj11.put("FILE_SEQ", ""+(i+1));
			            obj11.put("FILE_POS", paramVO.getFilePath());
			            obj11.put("USER_FILE_NM", paramVO.getOrigFileNms()[i]);
			            obj11.put("PHSC_FILE_NM", paramVO.getStoredFileNms()[i]);
			            obj11.put("FILE_SIZE", paramVO.getFileSizes()[i]);
			            obj11.put("DOWNLOAD_COUNT", 0);
			            obj11.put("REG_ID", REG_ID);
			          
			            result = mDao.setData("AML_90_01_01_03_doSave_NIC90B_2", obj11);
					}
				
				//추가3
				//hm.put("ATTCH_FILE_NO", ATTCH_FILE_NO);
				//hm.put("DR_OP_JKW_NO", DR_OP_JKW_NO);
				//mDao.setData("RBA_50_01_01_01_UPDATE_SRBA_VALT_SCHD_M", hm);
				//추가3
				mDao.commit();
			}
			//추가4
			else
			{
				for(int i=0; i < fileList.size(); i++)
				{
					//기존 파일 삭제
					String filePath = Constants._UPLOAD_QA_DIR+fileList.get(i).get("FILE_POS")+"/"+fileList.get(i).get("PHSC_FILE_NM");
					FileUtil.deleteFile(filePath);
				}	
				
				//db 파일 삭제
				mDao.setData("AML_90_01_01_03_doDelete_NIC90B_2", hm);		
				mDao.commit();
			}
			//추가4
				
				model.addAttribute("status", "success");
			    model.addAttribute("serviceMessage", "저장 처리되었습니다.");
			    
			    /* AML Page Log 등록 처리 모듈  **********************************************/
            	AMLCommonLogAction amlCommonLogAction =  new AMLCommonLogAction();
            	amlCommonLogAction.amlLogInsert(request, inHash);
                /* ***************************************************************************/
            	
			} catch(IOException e)
			{
				e.printStackTrace();
				try {
					if (mDao != null) {
						mDao.rollback();
					}
				} catch (AMLException e1) {
					Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
					model.addAttribute("status", "fail");
				    model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
				}
				Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
				model.addAttribute("status", "fail");
			    model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
			}catch(AMLException e)
			{
				e.printStackTrace();
				try {
					if (mDao != null) {
						mDao.rollback();
					}
				} catch (AMLException e1) {
					Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
					model.addAttribute("status", "fail");
				    model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
				}
				Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
				model.addAttribute("status", "fail");
			    model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
			}catch(Exception e)
			{
				e.printStackTrace();
				try {
					if (mDao != null) {
						mDao.rollback();
					}
				} catch (AMLException e1) {
					Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
					model.addAttribute("status", "fail");
				    model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
				}
				Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
				model.addAttribute("status", "fail");
			    model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
			}finally {
				mDao.close();
			}
			
			return "jsonView";
	  }
	

}
