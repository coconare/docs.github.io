/*
 * Copyright (c) 2008-2018 GTONE. All rights reserved.
 *
 * This software is the confidential and proprietary information of GTONE. You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered into with GTONE.
 */
package com.gtone.aml.server.AML_90.AML_90_01.AML_90_01_02;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.JDaoUtil;
import com.gtone.aml.dao.common.JDaoUtilSingle;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.aml.server.common.CommonAuth;
import com.gtone.aml.server.util.BizException;
import com.gtone.aml.user.SessionAML;
import com.gtone.express.Constants;
import com.gtone.express.server.helper.MessageHelper;
import com.gtone.express.util.FileUtil;
import com.itplus.common.server.user.SessionHelper;

import kr.co.itplus.jwizard.dataformat.DataSet;

/******************************************************************************************************************************************
 * @Description Q&A 상세조회
 *              Q&A詳細
 *              Q&A Details
 * @Group       GTONE, R&D센터/개발2본부
 * @Project     AML/RBA/FATCA/CRS/WLF
 * @Java        6.0 이상
 * @Author      서윤경, 김현일
 * @Since       2010. 9. 30.
 ******************************************************************************************************************************************
 * @Modifier    박상훈
 * @Update      2018. 3. 23.
 * @Alteration  코드정리
 ******************************************************************************************************************************************/

public class AML_90_01_02_03 extends GetResultObject {
	/**************************************************************************************************************************************
	 * Attributes
	 **************************************************************************************************************************************/

	/** 인스턴스 */
	private static AML_90_01_02_03 instance = null;

	/**************************************************************************************************************************************
	 * Methods
	 **************************************************************************************************************************************/

	/**
	 * 인스턴스 반환.
	 * <p>
	 * @return  <code>AML_90_01_02_03</code>
	 */
	public static AML_90_01_02_03 getInstance() {
		return instance == null ? (instance = new AML_90_01_02_03()) : instance;
	}

	/**
	 * Q&A 상세 조회<br>
	 * Q&A詳細照会
	 * <p>
	 * @param   input
	 *              화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *              インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *              Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 * @return  <code>DataObj</code>
	 *              GRID_DATA(Q&A 상세 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *              GRID_DATA(Q&A詳細 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *              GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 * @throws  <code>Exception</code>
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public DataObj doDetail(DataObj input) {
		DataObj output = null;
		DataObj output_file = null;
		JDaoUtil db = null;

		try {
			output = JDaoUtilSingle.getData("AML_90_01_02_03_doDetail_C_QA", (HashMap) input);

			// Stoed XSS
			// TITLE, CONTENT
			if ( output != null && output.size() > 0 ) {
				String sTitle = (String) output.get("TITLE");
				sTitle = sTitle.replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("\'", "&#039;");
				output.set("TITLE", sTitle);

				String sContent = (String) output.get("CONTENT");
				sContent = sContent.replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("\'", "&#039;");
				output.set("CONTENT", sContent);
			}

			// Attachments ==========================================================
			String BOARD_ID = input.getText("BOARD_ID");
			String BOARD_SEQ = input.getText("SEQ");

			Object[] obj1 = { BOARD_ID, BOARD_SEQ };

			output_file = JDaoUtilSingle.getData("AML_90_01_03_02_doDetail_NIC90B_2_ATTACH_FILE", obj1);
			if ( output_file.getCount("FILE_SEQ") > 0 ) {

				for ( int i = 0; i < output_file.getCount("FILE_SEQ"); i++ ) {
					output.put("FILE_SEQ", output_file.getText("FILE_SEQ", i), i);
					output.put("FILE_POS", output_file.getText("FILE_POS", i), i);
					output.put("USER_FILE_NM", output_file.getText("USER_FILE_NM", i), i);
					output.put("PHSC_FILE_NM", output_file.getText("PHSC_FILE_NM", i), i);
					output.put("FILE_SIZE", output_file.getText("FILE_SIZE", i), i);
					output.put("DOWNLOAD_COUNT", output_file.getText("DOWNLOAD_COUNT", i), i);
				}
			}
			// ===============================================================================
			String SEQ = input.getText("SEQ");
			db = new JDaoUtil();
			db.begin();
			if ( db.setData("AML_90_01_02_03_upViewCount_C_QA", new Object[] {SEQ}) != 1 ) {
				throw new BizException("View Count : update error..");
			}
			db.commit();
			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 출력 화면 상태 표시에 출력됨

			return output;

		} catch (Exception e) {
			Log.logAML(Log.ERROR, this, "doDetail", e.toString());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());

			return output;
		}
	}

	/**
	 * Q&A 삭제<br>
	 * Q&A削除
	 * <p>
	 * @param   input
	 *              화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *              インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *              Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 * @return  <code>DataObj</code>
	 *              GRID_DATA(Q&A 삭제 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *              GRID_DATA(Q&A削除 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *              GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 * @throws  <code>Exception</code>
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public DataObj doDelete(DataObj input) {
		DataObj output = new DataObj();
		String SEQ = input.getText("SEQ");
		String BOARD_ID = input.getText("BOARD_ID");

		@SuppressWarnings("unused")
		int result = 0;

		try {

			DataObj outputAuth = CommonAuth.checkWinAuth((SessionAML) input.get("SessionAML"), input.getText("pageID"));

			if ( "".equals(outputAuth.getText("U")) || "N".equals(outputAuth.getText("U")) ) {
				output = new DataObj();
				output.put("ERRCODE", "00001");
				output.put("ERRMSG", "권한이 없습니다.");
				return output;
			}
			output.add("BOARD_ID", input.getText("BOARD_ID"));
			output.add("BOARD_SEQ", input.getText("SEQ"));
			
			HashMap hm = new HashMap();
			hm.put("BOARD_ID", BOARD_ID);
			hm.put("BOARD_SEQ", SEQ);			
			System.out.println("BOARD_ID ::=======================::::::"+BOARD_ID);
			DataObj fdo = MDaoUtilSingle.getData("AML_90_01_01_03_getAttachSearch", hm);			
			List<HashMap> fileList = fdo.getRowsToMap();
			System.out.println("fileList ::::::::"+fileList.toString());			
			
			for(int i=0; i < fileList.size(); i++)
			{
				String filePath = Constants._UPLOAD_QA_DIR+fileList.get(i).get("FILE_POS")+"/"+fileList.get(i).get("PHSC_FILE_NM");
				FileUtil.deleteFile(filePath);
			}

			result = JDaoUtilSingle.setData("AML_90_01_02_03_doDelete_C_QA", (HashMap) input);
			result = MDaoUtilSingle.setData("AML_90_01_01_02_doDelete_NIC90B_2", output);

			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 출력 화면 상태 표시에 출력됨
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 화면 popUp 메세지 출력시 정의함.

			return output;

		} catch (IOException e) {
			Log.logAML(Log.ERROR, this, "doDelete", e.toString());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어

			return output;
		} catch (AMLException e) {
			Log.logAML(Log.ERROR, this, "doDelete", e.toString());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어

			return output;
		} catch (Exception e) {
			Log.logAML(Log.ERROR, this, "doDelete", e.toString());
			
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어
			
			return output;
		}
	}

	/**
	 * Q&A Comment 달기<br>
	 * Q&A詳細照会
	 * <p>
	 * @param   input
	 *              화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *              インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *              Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 * @return  <code>DataObj</code>
	 *              GRID_DATA(Q&A 상세 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *              GRID_DATA(Q&A詳細 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *              GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 * @throws  <code>Exception</code>
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public DataObj doSaveAnswerComment(DataObj input) {
		DataObj output = new DataObj();
		DataSet gdRes = null;
		SessionAML sess = (SessionAML) input.get("SessionAML");
		SessionHelper sessHelper = sess.getSessionHelper();
		String LOGIN_ID = sessHelper.getLoginId();
		String USER_ID = sessHelper.getUserId().toString();
		String ROLE_NM = sess.getsAML_ROLE_NAME();
		String USER_NM = sess.getsAML_USER_NAME();

		try {

			DataObj outputAuth = CommonAuth.checkWinAuth((SessionAML) input.get("SessionAML"), input.getText("pageID"));

			if ( "".equals(outputAuth.getText("U")) || "N".equals(outputAuth.getText("U")) ) {
				output = new DataObj();
				output.put("ERRCODE", "00001");
				output.put("ERRMSG", "권한이 없습니다.");
				return output;
			}

			input.put("LOGIN_ID", LOGIN_ID);
			input.put("USER_ID", USER_ID);
			input.put("ROLE_ID", sess.getsAML_ROLE_ID());
			input.put("ROLE_NM", ROLE_NM);
			input.put("USER_NM", USER_NM);

			MDaoUtilSingle.setData("AML_90_01_02_03_doAnswer_C_QA_ANSWER", (HashMap) input);
			MDaoUtilSingle.setData("AML_90_01_02_03_doAnswer_C_QA", (HashMap) input);

			output = MDaoUtilSingle.getData("AML_90_01_02_03_doSearch_C_QA_ANSWER_SEQ", (HashMap) input);

			output.put("CONTENT", input.getText("ANSWER"));
			output.put("SESS_LOGIN_ID", LOGIN_ID);
			output.put("SESS_USER_ID", USER_ID);
			output.put("SESS_ROLE_NM", ROLE_NM);
			output.put("SESS_USER_NM", USER_NM);

			gdRes = Common.setGridData(output);

			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 출력 화면 상태 표시에 출력됨

			return output;
		} catch (AMLException e) {
			Log.logAML(Log.ERROR, this, "doSaveAnswerComment", e.toString());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());

			return output;
		}
	}

	/**
	 * Q&A Comment 조회<br>
	 * Q&A詳細照会
	 * <p>
	 * @param   input
	 *              화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *              インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *              Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 * @return  <code>DataObj</code>
	 *              GRID_DATA(Q&A 상세 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *              GRID_DATA(Q&A詳細 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *              GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 * @throws  <code>Exception</code>
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public DataObj doSearch(DataObj input) {
		DataObj output = new DataObj();
		DataSet gdRes = null;
//		SessionAML sess = (SessionAML) input.get("SessionAML");
		// @SuppressWarnings("unused")
		// SessionHelper sessHelper = sess.getSessionHelper();

		try {
			output = MDaoUtilSingle.getData("AML_90_01_02_03_doSearch_C_QA_ANSWER", (HashMap) input);

			gdRes = Common.setGridData(output);

			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 출력 화면 상태 표시에 출력됨

			return output;

		} catch (AMLException e) {
			Log.logAML(Log.ERROR, this, "doSearch", e.toString());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());

			return output;
		}
	}

	/**
	 * Q&A Comment 삭제<br>
	 * Q&A詳細照会
	 * <p>
	 * @param   input
	 *              화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *              インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *              Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 * @return  <code>DataObj</code>
	 *              GRID_DATA(Q&A 상세 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *              GRID_DATA(Q&A詳細 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *              GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 * @throws  <code>Exception</code>
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public DataObj doDeleteAnswer(DataObj input) {
		DataObj output = new DataObj();

		try {

			DataObj outputAuth = CommonAuth.checkWinAuth((SessionAML) input.get("SessionAML"), input.getText("pageID"));

			if ( "".equals(outputAuth.getText("U")) || "N".equals(outputAuth.getText("U")) ) {
				output = new DataObj();
				output.put("ERRCODE", "00001");
				output.put("ERRMSG", "권한이 없습니다.");
				return output;
			}

			MDaoUtilSingle.setData("AML_90_01_02_03_doDelete_C_QA_ANSWER", (HashMap) input);

			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 출력 화면 상태 표시에 출력됨

			return output;

		} catch (AMLException e) {
			Log.logAML(Log.ERROR, this, "doDeleteAnswer", e.toString());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());

			return output;
		}
	}

	/**
	 * Q&A Comment 수정<br>
	 * Q&A詳細照会
	 * <p>
	 * @param   input
	 *              화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *              インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *              Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 * @return  <code>DataObj</code>
	 *              GRID_DATA(Q&A 상세 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *              GRID_DATA(Q&A詳細 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *              GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 * @throws  <code>Exception</code>
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public DataObj doUpdateAnswer(DataObj input) {
		DataObj output = new DataObj();

		try {

			DataObj outputAuth = CommonAuth.checkWinAuth((SessionAML) input.get("SessionAML"), input.getText("pageID"));

			if ( "".equals(outputAuth.getText("U")) || "N".equals(outputAuth.getText("U")) ) {
				output = new DataObj();
				output.put("ERRCODE", "00001");
				output.put("ERRMSG", "권한이 없습니다.");
				return output;
			}

			MDaoUtilSingle.setData("AML_90_01_02_03_doUpdate_C_QA_ANSWER", (HashMap) input);

			output.put("CONTENT", input.getText("CONTENT"));
			output.put("ANSWER_SEQ", input.getText("ANSWER_SEQ"));
			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 출력 화면 상태 표시에 출력됨

			return output;

		} catch (AMLException e) {
			Log.logAML(Log.ERROR, this, "getSearch", e.toString());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());

			return output;
		}
	}
}