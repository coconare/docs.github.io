/*
 * Copyright (c) 2008-2017 GTONE. All rights reserved.
 *
 * This software is the confidential and proprietary information of GTONE. You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered into with GTONE.
 */
package com.gtone.aml.server.AML_90.AML_90_01.AML_90_01_02;

import java.io.IOException;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.basic.common.util.Util;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.AML_90.AML_90_01.AML_90_01_02.AML_90_01_02_01_DAO;
import com.gtone.aml.dao.common.JDaoUtil;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.aml.server.common.CommonAuth;
import com.gtone.aml.user.SessionAML;
import com.gtone.express.server.helper.MessageHelper;//PHH 2009.03.02 다국어
import com.itplus.common.server.user.SessionHelper;

import jspeed.base.http.AttachFileDataSource;
import jspeed.base.http.MultipartRequest;
import jspeed.base.property.PropertyService;
import kr.co.itplus.jwizard.dataformat.DataSet;

/**
*<pre>
* Q&A 목록
* Q&A一覧
* Q&A List
*</pre>
*@author syk, hikim
*@version 1.0
*@history 1.0 2010-09-30
*/
public class AML_90_01_02_01 extends GetResultObject {

	private static AML_90_01_02_01 instance = null;

	/**
	 * getInstance
	 * @return AML_90_01_02_01
	 */
	public static AML_90_01_02_01 getInstance() {
		if ( instance == null ) {
			instance = new AML_90_01_02_01();
		}
		return instance;
	}

	/**
	 * <pre>
	 *   Q&A 목록 조회
	 * Q&A一覧の照会
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(Q&A 목록 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(Q&A一覧 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public DataObj getSearch(DataObj input) {

		DataObj output = null;
		DataSet gdRes = null;

		try {

			AML_90_01_02_01_DAO dao = new AML_90_01_02_01_DAO();
			output = dao.getSearch(input);

			if ( output != null ) {
				if ( output.getCount("SEQ") > 0 ) {
					for ( int i = 0; i < output.getCount("SEQ"); i++ ) {

						int FILE_ATT_YN = Integer.parseInt(output.get("FILE_ATT_YN", i).toString()) > 0 ? 1 : 0;
						output.put("FILE_ATT_YN", FILE_ATT_YN, i);
					}
				}
			}

			if ( "0".equals(output.getText("COUNT")) ) {
				output.put("ERRMSG", MessageHelper.getInstance().getMessage("0001", input.getText("LANG_CD"), "조회된 정보가 없습니다."));// PHH 2009.03.02 다국어
			} else {
				gdRes = Common.setGridData(output);
				output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어
			}

			output.put("ERRCODE", "00000");
			output.put("gdRes", gdRes); // Wise Grid Data

			return output;

		} catch (NumberFormatException e) {

			Log.logAML(Log.ERROR, this, "getSearch", e.toString());

			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어

			return output;
		} catch (Exception e) {

			Log.logAML(Log.ERROR, this, "getSearch", e.toString());

			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어

			return output;
		}
	}

	/**
	 * <pre>
	 *   Q&A 덧글 저장
	 * Q&A保存
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(Q&A 저장 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(Q&A保存 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	@SuppressWarnings("unchecked")
	public DataObj doAnswer(MultipartRequest req) {

		String filePath = PropertyService.getInstance().getProperty("aml.config", "uploadPath.notice");
		String fileFullPath = "";

		DataObj output = new DataObj();
		SessionHelper helper = new SessionHelper(req.getSession());

		@SuppressWarnings("unused")
		int result = 0;
		JDaoUtil daoUtil = null;
		try {

			/* 메소드명이 INSERT/UPDATE/DELETE/SAVE/ 명명규칙이 틀린경우 JAVA 소스에서 따로 구현함 */
			/* CRUD가 시작되기전 권한 체크 로직 추가 */
			DataObj outputAuth = CommonAuth.checkWinAuth(new SessionAML(req.getSession()), req.getParameter("pageID"));
			if ( "".equals(outputAuth.getText("U")) || "N".equals(outputAuth.getText("U")) ) {
				output = new DataObj();
				output.put("ERRCODE", "00001");
				output.put("ERRMSG", "권한이 없습니다.");
				return output;
			}

			daoUtil = new JDaoUtil();

			DataObj input = new DataObj();

			String SEQ = Util.nvl(req.getParameter("SEQ"));
			String REG_DT = jspeed.base.util.DateHelper.currentTime("yyyyMMdd");
			String PKG_NAME = Util.nvl(PropertyService.getInstance().getProperty("aml.config", "PKG_NAME"), "AML");
			String BOARD_ID = Util.nvl(req.getParameter("BOARD_ID"));
			String BOARD_SEQ = Util.nvl(req.getParameter("SEQ"));
			String REG_ID = Util.nvl(helper.getUserId());
			String KIND = Util.nvl(req.getParameter("KIND"));
			String TITLE = Util.nvl(req.getParameter("TITLE"));
			String CONTENT = Util.nvl(req.getParameter("CONTENT"));
			String REG_NAME = Util.nvl(req.getParameter("REG_NAME"));
			String STATE = Util.nvl(req.getParameter("STATE"));
			String PAR_SEQ = Util.nvl(req.getParameter("PAR_SEQ"));

			input.add("SEQ", SEQ);
			input.add("KIND", KIND);
			input.add("TITLE", TITLE);
			input.add("CONTENT", CONTENT);
			input.add("REG_ID", REG_ID);
			input.add("REG_NAME", REG_NAME);
			input.add("STATE", STATE);
			input.add("REG_DT", REG_DT);
			input.add("PKG_NAME", PKG_NAME);
			input.add("PAR_SEQ", PAR_SEQ);

			result = MDaoUtilSingle.setData("AML_90_01_02_01_doAnswer_C_QA", input);

			/*
			 * Attachments Positioning
			 */
			fileFullPath = filePath + "/" + BOARD_ID + "/" + BOARD_SEQ + "/";

			fileFullPath = fileFullPath.replace("/", System.getProperty("file.separator"));

			/*
			 * Attachments Save/ DB Attachment content DB Save
			 */

			if ( req.getAttach("NOTI_ATTACH") != null ) {

				AttachFileDataSource[] attachFileDSs = req.getAttachFiles("NOTI_ATTACH");
				String PHSC_FILE_NM = "";
				long fileLen = 0;
				for ( int i = 0; i < attachFileDSs.length; i++ ) {

					PHSC_FILE_NM = BOARD_SEQ + "_" + (i + 1);
					req.upload(attachFileDSs[i], fileFullPath, PHSC_FILE_NM);
					fileLen = attachFileDSs[i].getSize();
					if ( fileLen > 1 ) {
						fileLen = fileLen - 2;
					}
					Object[] obj1 = new Object[] { BOARD_ID
							                     , BOARD_SEQ
							                     , "" + (i + 1)
							                     , fileFullPath
							                     , attachFileDSs[i].getName()
							                     , PHSC_FILE_NM
							                     , fileLen
							                     , 0
							                     , REG_ID 
							                     };

					result = daoUtil.setData("AML_90_01_03_03_doSave_NIC90B_2", obj1);
				}
			}

			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", helper.getLangType(), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 출력 화면 상태 표시에 출력됨
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", helper.getLangType(), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 화면 popUp 메세지 출력시 정의함.

		} catch (AMLException e) {
			try {
				if ( daoUtil != null ) {
					daoUtil.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "doAnswer", ee.getMessage());
			}
			Log.logAML(Log.ERROR, this, "getSearch", e.toString());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", helper.getLangType(), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어

			return output;
		}  catch (IOException e) {
			try {
				if ( daoUtil != null ) {
					daoUtil.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "doAnswer", ee.getMessage());
			}
			Log.logAML(Log.ERROR, this, "getSearch", e.toString());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", helper.getLangType(), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어

			return output;
		} catch (Exception e) {
			try {
				if ( daoUtil != null ) {
					daoUtil.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "doAnswer", ee.getMessage());
			}
			Log.logAML(Log.ERROR, this, "getSearch", e.toString());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", helper.getLangType(), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어
		} finally {
			if ( daoUtil != null ) {
				daoUtil.close();
			}
		}
		return output;
	}
}
