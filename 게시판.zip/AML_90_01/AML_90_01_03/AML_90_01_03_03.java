/*
 * Copyright (c) 2008-2017 GTONE. All rights reserved.
 *
 * This software is the confidential and proprietary information of GTONE. You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered into with GTONE.
 */
package com.gtone.aml.server.AML_90.AML_90_01.AML_90_01_03;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.basic.common.util.Util;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.AMLCommonLogAction;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.JDaoUtil;
import com.gtone.aml.dao.common.MDaoUtil;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.express.Constants;
import com.gtone.express.domain.FileVO;
import com.gtone.express.server.helper.MessageHelper;
import com.gtone.express.util.FileUtil;
import com.itplus.common.server.user.SessionHelper;

import jbit.common.util.ParamUtil;
import jspeed.base.http.AttachFileDataSource;
import jspeed.base.http.MultipartRequest;
import jspeed.base.property.PropertyService;
import kr.co.itplus.jwizard.dataformat.DataSet;

/**
*<pre>
* 자료실 등록
* 資料室追加
* Resource Registration
*</pre>
*@author syk, hikim
*@version 1.0
*@history 1.0 2010-09-30
*/
@Controller
public class AML_90_01_03_03 extends GetResultObject {

	private static AML_90_01_03_03 instance = null;

	/**
	 * getInstance
	 * @return AML_90_01_03_03
	 */
	public static AML_90_01_03_03 getInstance() {
		if ( instance == null ) {
			instance = new AML_90_01_03_03();
		}
		return instance;
	}

	/**
	 * <pre>
	 *   자료실 저장
	 * 資料室の保存
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(자료실 저장 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(資料室の保存 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	public DataObj doSave(MultipartRequest req) {

		String filePath = PropertyService.getInstance().getProperty("aml.config", "uploadPath.notice");

		String fileFullPath = "";
		JDaoUtil daoUtil = null;

		DataObj output = new DataObj();
		SessionHelper helper = new SessionHelper(req.getSession());

		String BOARD_ID = Util.nvl(req.getParameter("BOARD_ID"));
		String TITLE = Util.nvl(req.getParameter("TITLE"));
		String BOARD_CONTENT = Util.nvl(req.getParameter("BOARD_CONTENT"));

		String REG_ID = Util.nvl(helper.getUserId());
		String REG_IP = Util.nvl(req.getRemoteAddr());
		String UPD_ID = REG_ID;

		String TEMP_01 = Util.nvl(req.getParameter("TEMP_01"));
		String TEMP_02 = Util.nvl(req.getParameter("TEMP_02"));
		String TEMP_03 = Util.nvl(req.getParameter("TEMP_03"));
		String TEMP_04 = Util.nvl(req.getParameter("TEMP_04"));
		String TEMP_05 = Util.nvl(req.getParameter("TEMP_05"));

		@SuppressWarnings("unused")
		int result = 0;

		try {
			daoUtil = new JDaoUtil();
			// PHH
			daoUtil.begin();

			int BOARD_SEQ = daoUtil.getData("AML_90_01_03_03_NIC90B_1_SEQ_nextval", new Object[0]).getInt("NIC90B_1_SEQ");

			Object[] obj1 = { BOARD_ID
					        , new Integer(BOARD_SEQ)
					        , TITLE
					        , BOARD_CONTENT
					        , REG_ID
					        , REG_IP
					        , UPD_ID
					        , TEMP_01
					        , TEMP_02
					        , TEMP_03
					        , TEMP_04
					        , TEMP_05 
					        };
			
			result = daoUtil.setData("AML_90_01_03_03_doSave_NIC90B_1", obj1);

			/*
			 * Attachments Positioning
			 */
			fileFullPath = filePath + "/" + BOARD_ID + "/" + BOARD_SEQ + "/";

			fileFullPath = fileFullPath.replace("/", System.getProperty("file.separator"));

			/*
			 * Attachments Save/ DB Attachment content DB Save
			 */

			if ( req.getAttach("NOTI_ATTACH") != null ) {

				AttachFileDataSource[] attachFileDSs = req.getAttachFiles("NOTI_ATTACH");
				String PHSC_FILE_NM = "";
				long fileLen = 0;
				for ( int i = 0; i < attachFileDSs.length; i++ ) {

					PHSC_FILE_NM = BOARD_SEQ + "_" + (i + 1);
					req.upload(attachFileDSs[i], fileFullPath, PHSC_FILE_NM);
					fileLen = attachFileDSs[i].getSize();
					
					if ( fileLen > 1 ) {
						fileLen = fileLen - 2;
					}
					
					obj1 = new Object[] { BOARD_ID
							            , BOARD_SEQ
							            , "" + (i + 1)
							            , fileFullPath
							            , attachFileDSs[i].getName()
							            , PHSC_FILE_NM
							            , fileLen
							            , 0
							            , REG_ID 
							            };

					result = daoUtil.setData("AML_90_01_03_03_doSave_NIC90B_2", obj1);
				}
			}
			daoUtil.commit();

			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", helper.getLangType(), "정상 처리되었습니다."));
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", helper.getLangType(), "정상 처리되었습니다."));

		} catch (IOException e) {
			try {
				if ( daoUtil != null ) {
					daoUtil.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "doSave", ee.toString());
			}

			Log.logAML(Log.ERROR, this, "doSave", e.toString());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", helper.getLangType(), "처리중 오류가 발생하였습니다."));
		} catch (NumberFormatException e) {
			try {
				if ( daoUtil != null ) {
					daoUtil.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "doSave", ee.toString());
			}

			Log.logAML(Log.ERROR, this, "doSave", e.toString());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", helper.getLangType(), "처리중 오류가 발생하였습니다."));
		} catch (Exception e) {
			try {
				if ( daoUtil != null ) {
					daoUtil.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "doSave", ee.toString());
			}

			Log.logAML(Log.ERROR, this, "doSave", e.toString());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", helper.getLangType(), "처리중 오류가 발생하였습니다."));
		} finally {
			try {
				if ( daoUtil != null ) {
					daoUtil.close();
				}
			} catch (Exception e) {
			}
		}

		return output;
	}
	
	  @SuppressWarnings({ "rawtypes", "unchecked" })
	  @RequestMapping("/bbs/doDownSave.do")
	  public String doSave(HttpServletRequest request, ModelMap model ,FileVO paramVO, @RequestParam Map inHash ) 
	  {
		  System.out.println("=========================================DO NOTIO SVE========================");
			//DataObj output = new DataObj();
			SessionHelper helper = new SessionHelper(request.getSession());
			String BOARD_ID = Util.nvl(request.getParameter("BOARD_ID"));			
			String REG_ID = Util.nvl(helper.getUserId());
			String PKG_NAME = Util.nvl(PropertyService.getInstance().getProperty("aml.config", "PKG_NAME"), "AML");
			//String TITLE = Util.nvl(request.getParameter("TITLE"));
			//String BOARD_CONTENT = Util.nvl(request.getParameter("BOARD_CONTENT"));
			String REG_IP = Util.nvl(request.getRemoteAddr());
			String UPD_ID = REG_ID;
			//String TEMP_01 = Util.nvl(request.getParameter("TEMP_01"));
			//String TEMP_02 = Util.nvl(request.getParameter("TEMP_02"));
			//String TEMP_03 = Util.nvl(request.getParameter("TEMP_03"));
			//String TEMP_04 = Util.nvl(request.getParameter("TEMP_04"));
			//String TEMP_05 = Util.nvl(request.getParameter("TEMP_05"));

			MDaoUtil mDao = null;			
			try
			{	
				mDao = new MDaoUtil();
				HashMap hm = ParamUtil.getReqParamHashMap(request);
				System.out.println("hm ::::::::"+hm.toString());
				
				DataObj BOARD_SEQ = mDao.getData("AML_90_01_03_03_NIC90B_1_SEQ_nextval", hm);
				DataSet ds = Common.setGridData(BOARD_SEQ);
				//System.out.println("NOTI ID ========================== "+BOARD_SEQ);
				hm.put("BOARD_SEQ", ds.getString(0, "NIC90B_1_SEQ"));
				hm.put("PKG_NAME", PKG_NAME);
				hm.put("REG_IP", REG_IP);
				hm.put("REG_ID", REG_ID);
				hm.put("UPD_ID", UPD_ID);
				mDao.setData("AML_90_01_03_03_doSave_NIC90B_1", hm);
							  

		        @SuppressWarnings("unused")
		        int result = 0;
		       
				
		        // 파일 이동 및 처리
				if(null != paramVO.getFilePaths()) 
				{
					for(int i = 0; i < paramVO.getFilePaths().length; i++)
					{
						if(paramVO.getFilePaths()[i].indexOf(Constants.COMMON_TEMP_FILE_UPLOAD_DIR) > -1)
						{
							File	tempDir		= new File(paramVO.getFilePaths()[i]);				
							File	tempFile	= new File(tempDir, paramVO.getStoredFileNms()[i]);
							
							if(tempFile.isFile())
							{								
								File	realFile	= FileUtil.renameTo(tempFile, Constants._UPLOAD_DOWN_DIR);
								
								String[]	filePath	= paramVO.getFilePaths();
								filePath[i]				= StringUtils.replace(realFile.getParent(),Constants._UPLOAD_DOWN_DIR,"");
								
								paramVO.setFilePath(filePath[i]);
								paramVO.setFilePath(paramVO.getFilePath().replaceAll("\\\\", "/"));
							}
							else
							{
								String[]	filePath	= paramVO.getFilePaths();
								filePath[i]				= StringUtils.replace(filePath[i], Constants.COMMON_TEMP_FILE_UPLOAD_DIR, Constants._UPLOAD_DOWN_DIR);
								
								paramVO.setFilePath(filePath[0]);
								paramVO.setFilePath(paramVO.getFilePath().replaceAll("\\\\", "/"));
							}
						}else {
							String[]	filePath	= paramVO.getFilePaths();
							filePath[i]				= StringUtils.replace(filePath[i], Constants.COMMON_TEMP_FILE_UPLOAD_DIR, Constants._UPLOAD_DOWN_DIR);
							
							paramVO.setFilePath(filePath[i]);
							paramVO.setFilePath(paramVO.getFilePath().replaceAll("\\\\", "/"));
						}
					}
			
					 System.out.println("FILEPATH============="+paramVO.getFilePath());
					//파일일괄 인서트
					for(int i = 0; i < paramVO.getFilePaths().length; i++)
					{
						DataObj obj11 = new DataObj();
						obj11.put("BOARD_ID", BOARD_ID);
			            obj11.put("BOARD_SEQ", ds.getString(0, "NIC90B_1_SEQ"));
			            obj11.put("FILE_SEQ", ""+(i+1));
			            obj11.put("FILE_POS", paramVO.getFilePath());
			            obj11.put("USER_FILE_NM", paramVO.getOrigFileNms()[i]);
			            obj11.put("PHSC_FILE_NM", paramVO.getStoredFileNms()[i]);
			            obj11.put("FILE_SIZE", paramVO.getFileSizes()[i]);
			            obj11.put("DOWNLOAD_COUNT", 0);
			            obj11.put("REG_ID", REG_ID);
			          
			            result = mDao.setData("AML_90_01_01_03_doSave_NIC90B_2", obj11);
						
					}
				}
				
				mDao.commit();
				
				model.addAttribute("status", "success");
			    model.addAttribute("serviceMessage", "저장 처리되었습니다.");
			    
			    /* AML Page Log 등록 처리 모듈  **********************************************/
            	AMLCommonLogAction amlCommonLogAction =  new AMLCommonLogAction();
            	amlCommonLogAction.amlLogInsert(request, inHash);
                /* ***************************************************************************/
            	
			}
			catch(IndexOutOfBoundsException e)
			{
				e.printStackTrace();
				try {
					if (mDao != null) {
						mDao.rollback();
					}
				} catch (AMLException e1) {
					Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
					model.addAttribute("status", "fail");
					model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
				}
				Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
				model.addAttribute("status", "fail");
				model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
			}catch(AMLException e)
			{
				e.printStackTrace();
				try {
					if (mDao != null) {
						mDao.rollback();
					}
				} catch (AMLException e1) {
					Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
					model.addAttribute("status", "fail");
					model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
				}
				Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
				model.addAttribute("status", "fail");
				model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
			}
			catch(Exception e)
			{
				e.printStackTrace();
				try {
					if (mDao != null) {
						mDao.rollback();
					}
				} catch (AMLException e1) {
					Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
					model.addAttribute("status", "fail");
				    model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
				}
				Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
				model.addAttribute("status", "fail");
			    model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
			}finally {
				mDao.close();
			}
			
			return "jsonView";
	  }

	  @SuppressWarnings({ "rawtypes", "unchecked" })
	  @RequestMapping("/bbs/doDownUpdate.do")
	  public String doUpdate(HttpServletRequest request, ModelMap model ,FileVO paramVO, @RequestParam Map inHash ) 
	  {
		  System.out.println("=========================================DO NOTIO SVE========================");
			//DataObj output = new DataObj();
			SessionHelper helper = new SessionHelper(request.getSession());
			String BOARD_ID = Util.nvl(request.getParameter("BOARD_ID"));			
		    String UPD_ID 	= Util.nvl(helper.getUserId());
		    String BOARD_SEQ     = Util.nvl(request.getParameter("BOARD_SEQ"));

			

			MDaoUtil mDao = null;			
			try
			{	
				mDao = new MDaoUtil();
				HashMap hm = ParamUtil.getReqParamHashMap(request);
				System.out.println("hm ::::::::"+hm.toString());
				
				hm.put("UPD_ID", UPD_ID);
				hm.put("BOARD_SEQ", BOARD_SEQ);
				mDao.setData("AML_90_01_03_04_doUpdate_NIC90B_1", hm);
				

		        @SuppressWarnings("unused")
		        int result = 0;
		       
		        //기존 파일목록  수정추가1
				DataObj fdo = MDaoUtilSingle.getData("AML_90_01_01_03_getAttachSearch",hm);
				List<HashMap> fileList = fdo.getRowsToMap();
				System.out.println("fileList ::::::::"+fileList.toString());				
				//추가1
				
		        // 파일 이동 및 처리
				if((null == paramVO.getFilePaths()) == false) 
				{
					for(int i = 0; i < paramVO.getFilePaths().length; i++)
					{
						if(paramVO.getFilePaths()[i].indexOf(Constants.COMMON_TEMP_FILE_UPLOAD_DIR) > -1)
						{
							File	tempDir		= new File(paramVO.getFilePaths()[i]);				
							File	tempFile	= new File(tempDir, paramVO.getStoredFileNms()[i]);
							
							if(tempFile.isFile())
							{								
								File	realFile	= FileUtil.renameTo(tempFile, Constants._UPLOAD_DOWN_DIR);
								
								String[]	filePath	= paramVO.getFilePaths();
								filePath[i]				= StringUtils.replace(realFile.getParent(),Constants._UPLOAD_DOWN_DIR,"");
								
								paramVO.setFilePath(filePath[i]);
								paramVO.setFilePath(paramVO.getFilePath().replaceAll("\\\\", "/"));
							}
							else
							{
								String[]	filePath	= paramVO.getFilePaths();
								filePath[i]				= StringUtils.replace(filePath[i], Constants.COMMON_TEMP_FILE_UPLOAD_DIR, Constants._UPLOAD_DOWN_DIR);
								
								paramVO.setFilePath(filePath[0]);
							}
						}else {							
							String[]	filePath	= paramVO.getFilePaths();
							filePath[i]				= StringUtils.replace(filePath[i], Constants.COMMON_TEMP_FILE_UPLOAD_DIR, Constants._UPLOAD_DOWN_DIR);
							
							paramVO.setFilePath(filePath[0]);
							paramVO.setFilePath(paramVO.getFilePath().replaceAll("\\\\", "/"));
						}
					}
					
					System.out.println("fileList ::::::::"+fileList.toString());
					//기존파일 목록 비교 후 삭제처리	수정추가 2					
					for(int i=0; i < fileList.size(); i++)
					{
						boolean btn = false;
						 
						for(int k = 0; k < paramVO.getFilePaths().length; k++)
						{					
							String r = paramVO.getStoredFileNms()[k];			
							
							if(r.equals(fileList.get(i).get("PHSC_FILE_NM")))
							{
								//btn = true;
								btn = false;						
								break;
							}
							else
							{
								//btn = false;						
								//break;
								btn = true;
							}
						}
						
						//넘어온 값과 기존파일목록에 존재하지 않으면 삭제
						if(btn)
						{
							String filePath = Constants._UPLOAD_DOWN_DIR+fileList.get(i).get("FILE_POS")+"/"+fileList.get(i).get("PHSC_FILE_NM");
							FileUtil.deleteFile(filePath);
						}
					}
					
					//db 파일 삭제
					mDao.setData("AML_90_01_01_03_doDelete_NIC90B_2", hm);					
					
				/*
				 * String RPT_GJDT = Util.replace(Util.nvl(hm.get("RPT_GJDT")), "-", ""); String
				 * FIU_RPT_GJDT = Util.replace(Util.nvl(hm.get("FIU_RPT_GJDT")), "-", "");
				 * String DR_OP_JKW_NO = Util.nvl(helper.getLoginId()); String ATTCH_FILE_NO =
				 * Util.nvl(hm.get("ATTCH_FILE_NO")); String BAS_YYMM =
				 * Util.replace(Util.nvl(hm.get("BAS_YYMM")), "-", "");
				 * 
				 * if("".equals(ATTCH_FILE_NO)) { // output =
				 * mDao.getData("comm.RBA_10_02_01_01_getRbaAttchFileSeq", hm); output =
				 * mDao.getData("AML_90_01_01_03_NIC90B_2_SEQ_nextval", hm); ATTCH_FILE_NO =
				 * output.getText("SEQ"); }
				 * 
				 * Log.logAML(Log.DEBUG, this, "#### ATTCH_FILE_NO!!! [" + ATTCH_FILE_NO+ "]");
				 * /// 추가2
				 */					 
					//파일일괄 인서트
					
					System.out.println("hm ::::::::"+hm.toString());
					for(int i = 0; i < paramVO.getFilePaths().length; i++)
					{
						DataObj obj11 = new DataObj();
						obj11.put("BOARD_ID", BOARD_ID);
			            obj11.put("BOARD_SEQ", BOARD_SEQ);
			            obj11.put("FILE_SEQ", ""+(i+1));
			            obj11.put("FILE_POS", paramVO.getFilePath());
			            obj11.put("USER_FILE_NM", paramVO.getOrigFileNms()[i]);
			            obj11.put("PHSC_FILE_NM", paramVO.getStoredFileNms()[i]);
			            obj11.put("FILE_SIZE", paramVO.getFileSizes()[i]);
			            obj11.put("DOWNLOAD_COUNT", 0);
			            obj11.put("REG_ID", UPD_ID);
			          
			            result = mDao.setData("AML_90_01_01_03_doSave_NIC90B_2", obj11);
					}
				
				//추가3
				//hm.put("ATTCH_FILE_NO", ATTCH_FILE_NO);
				//hm.put("DR_OP_JKW_NO", DR_OP_JKW_NO);
				//mDao.setData("RBA_50_01_01_01_UPDATE_SRBA_VALT_SCHD_M", hm);
				//추가3
				mDao.commit();
			}
			//추가4
			else
			{
				for(int i=0; i < fileList.size(); i++)
				{
					//기존 파일 삭제
					String filePath = Constants._UPLOAD_DOWN_DIR+fileList.get(i).get("FILE_POS")+"/"+fileList.get(i).get("PHSC_FILE_NM");
					FileUtil.deleteFile(filePath);
				}	
				
				//db 파일 삭제
				mDao.setData("AML_90_01_01_03_doDelete_NIC90B_2", hm);		
				mDao.commit();
			}
			//추가4
				
				model.addAttribute("status", "success");
			    model.addAttribute("serviceMessage", "저장 처리되었습니다.");

			    /* AML Page Log 등록 처리 모듈  **********************************************/
            	AMLCommonLogAction amlCommonLogAction =  new AMLCommonLogAction();
            	amlCommonLogAction.amlLogInsert(request, inHash);
                /* ***************************************************************************/
            	
			}
			catch(IOException e)
			{
				e.printStackTrace();
				try {
					if (mDao != null) {
						mDao.rollback();
					}
				} catch (AMLException e1) {
					Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
					model.addAttribute("status", "fail");
					model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
				}
				Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
				model.addAttribute("status", "fail");
				model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
			}catch(AMLException e)
			{
				e.printStackTrace();
				try {
					if (mDao != null) {
						mDao.rollback();
					}
				} catch (AMLException e1) {
					Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
					model.addAttribute("status", "fail");
					model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
				}
				Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
				model.addAttribute("status", "fail");
				model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
			}
			catch(Exception e)
			{
				e.printStackTrace();
				try {
					if (mDao != null) {
						mDao.rollback();
					}
				} catch (AMLException e1) {
					Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
					model.addAttribute("status", "fail");
				    model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
				}
				Log.logAML(Log.ERROR,this,"doSave",e.toString()); 
				model.addAttribute("status", "fail");
			    model.addAttribute("serviceMessage", "저장 처리 중 오류가 발생되었습니다.");
			}
			finally {
				mDao.close();
			}
			
			return "jsonView";
	  }
}
