/*
 * Copyright (c) 2008-2017 GTONE. All rights reserved.
 *
 * This software is the confidential and proprietary information of GTONE. You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered into with GTONE.
 */
package com.gtone.aml.server.AML_90.AML_90_01.AML_90_01_03;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.JDaoUtil;
import com.gtone.aml.dao.common.JDaoUtilSingle;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.aml.server.util.BizException;
import com.gtone.express.Constants;
import com.gtone.express.server.helper.MessageHelper;
import com.gtone.express.util.FileUtil;

/**
*<pre>
* 자료실 상세
* 資料室詳細
* Resource Info.
*</pre>
*@author syk, hikim
*@version 1.0
*@history 1.0 2010-09-30
*/
public class AML_90_01_03_02 extends GetResultObject {

	private static AML_90_01_03_02 instance = null;

	/**
	 * getInstance
	 * @return AML_90_01_03_02
	 */
	public static AML_90_01_03_02 getInstance() {
		if ( instance == null ) {
			instance = new AML_90_01_03_02();
		}
		return instance;
	}

	/**
	 * <pre>
	 *   자료실 상세 조회
	 * 資料室の詳細照会
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(자료실 상세 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(資料室の詳細 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	public DataObj doSearch(DataObj input) {

		DataObj output = new DataObj();
		DataObj output_file = new DataObj();
		JDaoUtil db = null;

		try {

			String BOARD_ID = input.getText("BOARD_ID");
			String BOARD_SEQ = input.getText("BOARD_SEQ");

			// 자료실만 업데이트 처줌
			if ( "AML_01".equals(BOARD_ID) ) {

				String query_id = "AML_90_01_03_01_getSearch";
				String sql = JDaoUtilSingle.getSQL(query_id);
				sql += " and BOARD_SEQ = ? ";

				Object[] obj = { BOARD_ID, BOARD_SEQ };
				output = JDaoUtilSingle.getData(query_id, sql, obj);

				// Stoed XSS
				// TITLE, CONTENT
				if ( output != null && output.size() > 0 ) {
					String sTitle = (String) output.get("TITLE");
					sTitle = sTitle.replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("\'", "&#039;");
					output.set("TITLE", sTitle);

					String sContent = (String) output.get("CONTENT");
					sContent = sContent.replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("\'", "&#039;");
					output.set("CONTENT", sContent);
				}

				// Attachments ==========================================================
				output_file = JDaoUtilSingle.getData("AML_90_01_03_02_doDetail_NIC90B_2_ATTACH_FILE", obj);
				if ( output_file.getCount("FILE_SEQ") > 0 ) {

					for ( int i = 0; i < output_file.getCount("FILE_SEQ"); i++ ) {
						output.put("FILE_SEQ", output_file.getText("FILE_SEQ", i), i);
						output.put("FILE_POS", output_file.getText("FILE_POS", i), i);
						output.put("USER_FILE_NM", output_file.getText("USER_FILE_NM", i), i);
						output.put("PHSC_FILE_NM", output_file.getText("PHSC_FILE_NM", i), i);
						output.put("FILE_SIZE", output_file.getText("FILE_SIZE", i), i);
						output.put("DOWNLOAD_COUNT", output_file.getText("DOWNLOAD_COUNT", i), i);
					}
				}
				// ===============================================================================
				db = new JDaoUtil();
				db.begin();
				if ( db.setData("AML_90_01_03_02_upViewCount_NIC90B_1", new Object[] { BOARD_ID, BOARD_SEQ }) != 1 ) {
					throw new BizException("View Count : update error..");
				}
				db.commit();

			} else if ( "RBA_10".equals(BOARD_ID) ) { // RBA_10_03_03_01 RBA-개선활동-자료관리 화면에서 호출시 20190201
				output = MDaoUtilSingle.getData("RBA_10_03_03_01_getAttchFileInfo", input);

			} else {

				Object[] obj = { BOARD_ID, BOARD_SEQ };
				// Attachments ==========================================================
				output = JDaoUtilSingle.getData("AML_90_01_03_02_doDetail_NIC90B_2_ATTACH_FILE", obj);
				// ===============================================================================

			}

			output.put("ERRCODE", "00000");
			output.put("ERRMSG", "");

		} catch (AMLException e) {

			Log.logAML(Log.ERROR, this.getClass(), "doSearch", e.getMessage());
			output = new DataObj();

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
		} catch (Exception e) {

			Log.logAML(Log.ERROR, this.getClass(), "doSearch", e.getMessage());
			output = new DataObj();

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
		} finally {
			if ( db != null ) {
				db.close();
			}
		}
		return output;
	}

	/**
	 * <pre>
	 *   자료실 삭제
	 * 資料室の削除
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(자료실 삭제 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(資料室の削除 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	public DataObj goDelete(DataObj input) {

		DataObj output = new DataObj();

		String BOARD_ID = input.getText("BOARD_ID");
		String BOARD_SEQ = input.getText("BOARD_SEQ");

		@SuppressWarnings("unused")
		int result = 0;
		JDaoUtil db = null;
		try {
			HashMap hm = new HashMap();
			hm.put("BOARD_ID", BOARD_ID);
			hm.put("BOARD_SEQ", BOARD_SEQ);			
			
			DataObj fdo = MDaoUtilSingle.getData("AML_90_01_01_03_getAttachSearch", hm);			
			List<HashMap> fileList = fdo.getRowsToMap();
			System.out.println("fileList ::::::::"+fileList.toString());			
			
			for(int i=0; i < fileList.size(); i++)
			{
				String filePath = Constants._UPLOAD_DOWN_DIR+fileList.get(i).get("FILE_POS")+"/"+fileList.get(i).get("PHSC_FILE_NM");
				FileUtil.deleteFile(filePath);
			}
			
			db = new JDaoUtil();
			db.begin();

			Object[] obj1 = { BOARD_ID, BOARD_SEQ };

			result = db.setData("AML_90_01_03_02_doDelete_NIC90B_1", obj1);
			result = db.setData("AML_90_01_03_02_doDelete_NIC90B_2", obj1);

			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));

			db.commit();

		} catch (IOException e) {

			try {
				if ( db != null ) {
					db.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "goDelete", ee.getMessage());
			}

			Log.logAML(Log.ERROR, this, "goDelete", e.getMessage());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어
		} catch (AMLException e) {

			try {
				if ( db != null ) {
					db.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "goDelete", ee.getMessage());
			}

			Log.logAML(Log.ERROR, this, "goDelete", e.getMessage());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어
		} catch (Exception e) {

			try {
				if ( db != null ) {
					db.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "goDelete", ee.getMessage());
			}

			Log.logAML(Log.ERROR, this, "goDelete", e.getMessage());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어
		} finally {
			try {
				if ( db != null ) {
					db.close();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "goDelete", ee.getMessage());
			}
		}
		return output;
	}

	/**
	 * <pre>
	 *   다운로드파일 저장
	 * ダウンロードファイルの保存
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(다운로드파일 저장 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(ダウンロードファイルの保存 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	public DataObj doDownUpdate(DataObj input) {

		DataObj output = new DataObj();

		String BOARD_ID = input.getText("BOARD_ID");
		String BOARD_SEQ = input.getText("BOARD_SEQ");
		String FILE_SEQ = input.getText("FILE_SEQ");

		@SuppressWarnings("unused")
		int result = 0;
		JDaoUtil db = null;
		try {
			db = new JDaoUtil();
			db.begin();

			Object[] obj1 = { BOARD_ID, BOARD_SEQ, FILE_SEQ };

			result = db.setData("AML_90_01_03_02_upDownCount_NIC90B_2", obj1);

			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));

			db.commit();

		} catch (Exception e) {

			try {
				if ( db != null ) {
					db.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "doDownUpdate", ee.getMessage());
			}

			Log.logAML(Log.ERROR, this, "doDownUpdate", e.getMessage());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어
		} finally {
			try {
				if ( db != null ) {
					db.close();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "doDownUpdate", ee.getMessage());
			}
		}
		return output;
	}

}
