package com.gtone.aml.server.AML_90.AML_90_01.AML_90_01_03;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.JDaoUtilSingle;
import com.gtone.express.server.helper.MessageHelper;

/**
*<pre>
* 자료실
* 資料室
* Resource Center
*</pre>
*@author syk, hikim
*@version 1.0
*@history 1.0 2010-09-30
*/
public class AML_90_01_03_01 extends GetResultObject {

	private static AML_90_01_03_01 instance = null;

	/**
	 * getInstance
	 * @return AML_90_01_03_01
	 */
	public static AML_90_01_03_01 getInstance() {
		if ( instance == null ) {
			instance = new AML_90_01_03_01();
		}
		return instance;
	}

	/**
	 * <pre>
	 *   자료실 목록 조회
	 * 資料室一覧の照会
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(자료실 목록 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(資料室一覧 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public DataObj getSearch(DataObj input) {

		DataObj output = new DataObj();
		DataObj condition = new DataObj();

		try {

			// =============================================================================================
			// int rowPerPage = Integer.parseInt(input.getText("rowPerPage").equals("")?"10":input.getText("rowPerPage"));
			// int thisPage = Integer.parseInt(input.getText("thisPage").equals("")?"1":input.getText("thisPage"));
			// int from = (thisPage-1)*rowPerPage + 1;
			// int to = thisPage*rowPerPage;

			String sql_condtion = "";
			String gubun = input.getText("gubun");
			String searchWord = input.getText("searchWord");

			condition.add("condition", input.getText("BOARD_ID"));

			if ( "TITLE".equals(gubun) ) {
				sql_condtion += " and UPPER(TITLE) like '%'||UPPER(?)||'%' ";
				condition.add("condition", searchWord);
			} else if ( "BOARD_CONTENT".equals(gubun) ) {
				sql_condtion += " and UPPER(BOARD_CONTENT) like '%'||UPPER(?)||'%' ";
				condition.add("condition", searchWord);
			}

			String query_id = "AML_90_01_03_01_getSearch";
			String queryStat = JDaoUtilSingle.getSQL(query_id);

			String sql_count = "select count(*) as COUNT from ( " + queryStat + sql_condtion + " ) AA ";
			String sql = "select * from ( " + queryStat + sql_condtion + " )  AA ";
			// sql += " where idx >= "+from+" and idx <= "+to+" order by idx asc";

			DataObj output_count = JDaoUtilSingle.getData(query_id, sql_count, Common.getConObject(condition));
			output = JDaoUtilSingle.getData(query_id, sql, Common.getConObject(condition));

			output.add("COUNT", output_count.getText("COUNT"));
			// =============================================================================================

			List gdRes = new ArrayList();

			if ( output.getCount("BOARD_SEQ") > 0 ) {

				String IDX;
				String BOARD_ID;
				String BOARD_SEQ;
				String TITLE;
				String BOARD_CONTENT;
				String VIEW_COUNT;
				String REG_ID;
				String REG_NM;
				String REG_IP;
				String REG_DT;
				String UPD_ID;
				String UPD_NM;
				String UPD_DT;
				String TEMP_01;
				String TEMP_02;
				String TEMP_03;
				String TEMP_04;
				String TEMP_05;
				String FILE_COUNT;

				for ( int i = 0; i < output.getCount("BOARD_SEQ"); i++ ) {
					HashMap map = new HashMap();

					IDX = output.getText("IDX", i);
					BOARD_ID = output.getText("BOARD_ID", i);
					BOARD_SEQ = output.getText("BOARD_SEQ", i);
					TITLE = output.getText("TITLE", i);
					BOARD_CONTENT = output.getText("BOARD_CONTENT", i);
					VIEW_COUNT = output.getText("VIEW_COUNT", i);
					REG_ID = output.getText("REG_ID", i);
					REG_NM = output.getText("REG_NM", i);
					REG_IP = output.getText("REG_IP", i);
					REG_DT = output.getText("REG_DT", i);
					UPD_ID = output.getText("UPD_ID", i);
					UPD_NM = output.getText("UPD_NM", i);
					UPD_DT = output.getText("UPD_DT", i);
					TEMP_01 = output.getText("TEMP_01", i);
					TEMP_02 = output.getText("TEMP_02", i);
					TEMP_03 = output.getText("TEMP_03", i);
					TEMP_04 = output.getText("TEMP_04", i);
					TEMP_05 = output.getText("TEMP_05", i);
					FILE_COUNT = output.getText("FILE_COUNT", i);

					map.put("IDX", IDX);
					map.put("BOARD_ID", BOARD_ID);
					map.put("BOARD_SEQ", BOARD_SEQ);
					map.put("TITLE", TITLE);
					map.put("BOARD_CONTENT", BOARD_CONTENT);
					map.put("VIEW_COUNT", VIEW_COUNT);
					map.put("REG_ID", REG_ID);
					map.put("REG_NM", REG_NM);
					map.put("REG_IP", REG_IP);
					map.put("REG_DT", REG_DT);
					map.put("UPD_ID", UPD_ID);
					map.put("UPD_NM", UPD_NM);
					map.put("UPD_DT", UPD_DT);
					map.put("TEMP_01", TEMP_01);
					map.put("TEMP_02", TEMP_02);
					map.put("TEMP_03", TEMP_03);
					map.put("TEMP_04", TEMP_04);
					map.put("TEMP_05", TEMP_05);
					map.put("FILE_ATT_YN", ("0".equals(FILE_COUNT) ? "No" : "Yes"));

					gdRes.add(map);
				}

				HashMap paramMap = new HashMap();
				// paramMap.put("COUNT", output.getText("COUNT"));
				// paramMap.put("thisPage", thisPage);

				output.put("gdParam", paramMap);

			} else {
				HashMap paramMap = new HashMap();
				paramMap.put("thisPage", "0");
				paramMap.put("COUNT", output.getText("COUNT"));
				output.put("gdParam", paramMap);
				output.put("ERRMSG", MessageHelper.getInstance().getMessage("0001", input.getText("LANG_CD"), "조회된 정보가 없습니다."));// PHH 2009.03.02 다국어
			}
			output.put("ERRCODE", "00000");
			output.put("gdRes", gdRes); // Wise Grid Data

		} catch (Exception e) {

			Log.logAML(Log.ERROR, this.getClass(), "getSearch", e.getMessage());
			output = new DataObj();

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.toString());
		}

		return output;
	}

}
